package com.example.recipeapp.data

val DefaultIngredientSamples = listOf(
    "계란", "계란찜", "닭가슴살", "닭안심", "닭똥집",
    "소고기", "돼지고기", "두부", "치즈", "마늘", "양파"
)
